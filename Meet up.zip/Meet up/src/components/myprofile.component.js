import React, { Component } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import Swal from 'sweetalert';
import CreateProfile from './create-profile.component';
import DeleteIcon from '@material-ui/icons/Delete';
import IconButton from '@material-ui/core/IconButton';
import Tooltip from '@material-ui/core/Tooltip';
import Navbar from './navbar.component';



class Profile extends Component {
    constructor(props) {
        super(props);
        this.deleteProfile = this.deleteProfile.bind(this);
       //this.componentDidMount();
       
    }

    deleteProfile() {
         let result = window.confirm("Do You Want Delete")
       
        if (result) {

            axios.get("http://localhost:4000/profiles/delete/" + this.props.profile._id)
                .then(console.log('Delelted Successfully'))
                .catch(err => console.log(err));
        }
        window.location.reload(); // fast reloading
    }
    render() {
        return (
            <tr>
                <td className={this.props.profile.profile_completed ? 'completed': ''}> {this.props.profile.first_name} </td>
                <td className={this.props.profile.profile_completed ? 'completed': ''}> {this.props.profile.last_name} </td>
                <td className={this.props.profile.profile_completed ? 'completed': ''}> {this.props.profile.job_title} </td>
                <td className={this.props.profile.profile_completed ? 'completed': ''}> {this.props.profile.company_name} </td>
                <td className={this.props.profile.profile_completed ? 'completed': ''}> {this.props.profile.start_date} </td>
                <td className={this.props.profile.profile_completed ? 'completed': ''}> {this.props.profile.end_date} </td>
                <td className={this.props.profile.profile_completed ? 'completed': ''}> {this.props.profile.qualification} </td>
                <td className={this.props.profile.profile_completed ? 'completed': ''}> {this.props.profile.location_name} </td>
                <td className={this.props.profile.profile_completed ? 'completed': ''}> {this.props.profile.mobile_number} </td>
                <td>
                
                <Link to={"/edit/" + this.props.profile._id}>Edit</Link> &nbsp;&nbsp;
                <Tooltip title="Delete">
                    <IconButton aria-label="delete" onClick={this.deleteProfile}>
                        <DeleteIcon />
                    </IconButton>
                </Tooltip>
                    
        {/* <button onClick={this.deleteProfile} className="btn btn-link">Delete</button> */}
                </td>
            </tr >
        )
    }
} // exported from todo-list


export default class MyProfile extends React.Component {

    constructor(props) {
        super(props);
        this.state = { profiles: [], id: '', first_name:'', last_name: '', job_title: '', company_name: '', start_date: '', end_date: '', qualification: '', location_name: '', mobile_number: '' };
        this.componentDidMount();
    } // end of constructor

    componentDidMount() {
        axios.get("http://localhost:4000/profiles/")
            .then(response => {
                this.setState({ profiles: response.data });
            })
            .catch(function (error) {
                console.log(error);
            })
         
            
    }

    //iterating over profile array map() function is used in React to iterate over list of items or array of items
    profileList() {
        return this.state.profiles.map(function (currentProfile, i) {
            return <Profile profile={currentProfile} key={i} />
        })
    }


    render() {
        return (
            <div>
                <Navbar/>
            <div>
                <div style={{ marginTop: 10 }}>
                    <div>
                            <center>
                            <h2 className="text-success"><b>My Profile</b></h2>
                            </center>
                            <table className="table table-striped" style={{ marginTop: 20 }} >
                                <thead>
                                <tr className="table table-dark">
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Most Recent Job Title</th>
                                        <th>Most recent Company</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Qualification</th>
                                        <th>Location</th>
                                        <th>Mobile Number</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {this.profileList()}
                                </tbody>
                            </table>
                            <center>
                           <button> <Link to={"/post"} className="fa fa-comments">&nbsp;Post What's in your mind.!</Link></button> &nbsp;&nbsp;
                           </center>
                    </div>
                </div>
            </div>
        </div>
        );
    }
}

 