import React from 'react';
import axios from 'axios';

export default class EditProfile extends React.Component {

    constructor(props) {
        super(props);

        // binding text box onChange events
        this.onChangeFirstName = this.onChangeFirstName.bind(this);
        this.onChangeLastName = this.onChangeLastName.bind(this);
        this.onChangeJobTitle = this.onChangeJobTitle.bind(this);
        this.onChangeCompanyName = this.onChangeCompanyName.bind(this);
        this.onChangeStartDate = this.onChangeStartDate.bind(this);
        this.onChangeEndDate = this.onChangeEndDate.bind(this);
        this.onChangeQualification = this.onChangeQualification.bind(this);
        this.onChangeLocationName = this.onChangeLocationName.bind(this);
        this.onChangeMobileNumber = this.onChangeMobileNumber.bind(this);

        // binding onSubmit event
        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            first_name: '',
            last_name: '',
            job_title: '',
            company_name: '',
            start_date: '',
            end_date: '',
            qualification: '',
            location_name: '',
            mobile_number: '',          
        }
    } // end of constructor

    // retrieving data from database and loading in textboxes
    // search todos by id
    componentDidMount() {
        axios.get('http://localhost:4000/profiles/'
            + this.props.match.params.id)
            .then(response => {
                this.setState({
                    first_name: response.data.first_name,
                    last_name: response.data.last_name,
                    job_title: response.data.job_title,
                    company_name: response.data.company_name,
                    start_date: response.data.start_date,
                    end_date: response.data.end_date,
                    qualification:response.data.qualification,
                    location_name:response.data.location_name,
                    mobile_number:response.data.mobile_number                  
                })
            })
            .catch(function (error) {
                console.log(error);
            })
    }

    onChangeFirstName(e){
        this.setState({
            first_name: e.target.value
        });
    }

    onChangeLastName(e){
        this.setState({
            last_name: e.target.value
        });
    }

    onChangeJobTitle(e) {
        this.setState({
            job_title: e.target.value
        });
    }
    onChangeCompanyName(e) {
        this.setState({
            company_name: e.target.value
        });
    } 
    
    onChangeStartDate(e){
        this.setState({
            start_date: e.target.value
        });
    }

    onChangeEndDate(e){
        this.setState({
            end_date: e.target.value
        });
    }

    onChangeQualification(e) {
        this.setState({
            qualification: e.target.value
        });
    }
    onChangeLocationName(e) {
        this.setState({
            location_name: e.target.value
        });
    }
    onChangeMobileNumber(e) {
        this.setState({
            mobile_number: e.target.value
        });
    }
    
    onSubmit(e) {
        e.preventDefault();
        const obj = {
            first_name: this.state.first_name,
            last_name: this.state.last_name,
            job_title: this.state.job_title,
            company_name: this.state.company_name,
            start_date: this.state.start_date,
            end_date: this.state.end_date,
            qualification: this.state.qualification,
            location_name: this.state.location_name,
            mobile_number: this.state.mobile_number,
        };
        console.log(obj);
        // add
        axios.post('http://localhost:4000/profiles/update/' 
            + this.props.match.params.id, obj)
            .then(res => console.log(res.data));

        this.props.history.push('/myprofile');

    } // end of onSubmit() function

    render() {
        return (
            <div className="container" style={{backgroundColor:"lightblue"}}>
               <div className="offset-lg-2 col-lg-8"> 
                        <div style={{ marginTop: 10 }}>
                            <h3 className="text-primary">Update Profile..!</h3>
                <form onSubmit={this.onSubmit}>
                <div className="form-group">
                <i className="fa fa-user"/>&nbsp;
                        <label>First Name</label>
                        <input type="text" className="form-control"
                            value={this.state.first_name}
                            onChange={this.onChangeFirstName} />
                    </div>
                    <div className="form-group">
                <i className="fa fa-user"/>&nbsp;
                        <label>Last Name</label>
                        <input type="text" className="form-control"
                            value={this.state.last_name}
                            onChange={this.onChangeLastName} />
                    </div>
                <div className="form-group">
                <i className="fa fa-info-circle"/>&nbsp;
                        <label>Most recent Job Title</label>
                        <input type="text" className="form-control"
                            value={this.state.job_title}
                            onChange={this.onChangeJobTitle} />
                    </div>

                    <div className="form-group">
                    <i className="fa fa-building"/>&nbsp;
                        <label>Most recent Company</label>
                        <input type="text" className="form-control"
                            value={this.state.company_name}
                            onChange={this.onChangeCompanyName} />
                    </div>
                    <div className="form-group">
                <i className="fa fa-calendar"/>&nbsp;
                        <label>Start Date</label>
                        <input type="date" className="form-control"
                            value={this.state.start_date}
                            onChange={this.onChangeStartDate} />
                    </div>
                    <div className="form-group">
                <i className="fa fa-calendar"/>&nbsp;
                        <label>End Date</label>
                        <input type="date" className="form-control"
                            value={this.state.end_date}
                            onChange={this.onChangeEndDate} />
                    </div>
                    <div className="form-group">
                    <i className="fa fa-file"/>&nbsp;
                        <label>Qualification</label>
                        <input type="text" className="form-control"
                            value={this.state.qualification}
                            onChange={this.onChangeQualification} />
                    </div>

                    <div className="form-group">
                    <i className="fa fa-map-marker"/>&nbsp;
                        <label>Preferred Location</label>
                        <input type="text" className="form-control"
                            value={this.state.location_name}
                            onChange={this.onChangeLocationName} />
                    </div>

                    <div className="form-group">
                    <i className="fa fa-phone"/>&nbsp;
                        <label>Phone Number</label>
                        <input type="text" className="form-control"
                            value={this.state.mobile_number}
                            onChange={this.onChangeMobileNumber} />
                    </div>

                    <br />

                    <div className="form-group">
                    {/* <i className="fa fa-pencil-square-o"/> */}
                        <input type="submit" value="Update Profile"
                            className="btn btn-primary" />&nbsp;
                    </div>
                </form>
                </div>
                </div>
            </div>
        );
    }

}