import React from 'react';
import axios from 'axios';
import Form from 'react-validation/build/form';
import Input from 'react-validation/build/input';
 import { isEmail } from 'validator';
 import { Link } from 'react-router-dom';
import NotificationSystem from 'react-notification-system';


const required = (value, props) => {
    if (!value || (props.isCheckable && !props.checked)) {
        return <span className="form-error is-visible">Required</span>;
    }
};

const email = (value) => {
    if (!isEmail(value)) {
        return <span className="form-error is-visible">${value} is not a valid email.</span>;
    }
};

const isEqual = (value, props, components) => {
    const bothUsed = components.password[0].isUsed && components.confirm[0].isUsed;
    const bothChanged = components.password[0].isChanged && components.confirm[0].isChanged;

    if (bothChanged && bothUsed && components.password[0].value !== components.confirm[0].value) {
        return <span className="form-error is-visible">Passwords are not equal.</span>;
    }
};


class Register extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            // firstName:'',
            // lastName:'',
            email: '',
            password: '',
            error: ''

        };
    }

    _notificationSystem = null

    _addNotification = (level, msg) => {

        this._notificationSystem.addNotification({
            message: msg,
            level: level
        });
    }

    componentDidMount() {
        this._notificationSystem = this.refs.notificationSystem;

    }

    getRegister = (e) => {
        e.preventDefault();
        axios.post('http://localhost:4000/users/register', this.state).then(res => {

            console.log(res.data);
            window.alert("You Have successfully registered");
            // this._addNotification("success", "You have successfully registered.");
            window.location = '/login';

        })
            .catch(err => {
                console.log(err)
                console.error(err.response);
                var errors = err.response.data.errors === undefined ? [] : err.response.data.errors;

                for (var i = 0; i < errors.length; i++) {
                    this._addNotification("error", `${i + 1} -> ${errors[i].param}: ${errors[i].msg}`)
                }


            });

    }

    render() {
        return (
            <div>
            <nav className=" navbar navbar-expand-lg navbar-light bg-info">
     <a className="navbar-brand" href="http://meetup.com"
       rel="noopener noreferrer" target="_blank">
         <img src='images/handshake.png' width="30" height="30"
           alt="logo is missing" />
       </a>
 
       {/* Routes */}
       <Link to ="/"
           className="navbar-brand">Meet-UP</Link>
           <button className="navbar-toggler" type="button"
           data-toggle ="collapse" data-target="#collapsibleNavbar">
             <span className="navbar-toggler-icon"></span>
           </button>
       <div className="collpase navbar-collapse">
         <ul className="navbar-nav mr-auto">
         <li className="nav-item">
             <Link to="/about" className="nav-link text-white fa fa-home">
               <b>Home</b>
             </Link>
             
             </li>
             </ul>
             <ul className="navbar-nav ml-auto">
             <li>
             <Link to="/register" className="nav-link text-white fa fa-user-circle-o">
               <b>Join-Now</b>
             </Link>
             <Link to="/login" className="nav-link text-white fa fa-user-circle-o">
               <b>Sign-in</b>
             </Link>
            
           </li>
         </ul>
       </div>
     </nav>  
            <div>
                <div className="container">
                <div className="offset-lg-3 col-lg-6">
                    <div style={{ marginTop: 10 }}>
                        <h2 className="text-primary" align="center">Register</h2>
                            <h4 className="text-secondary" align="center">Make the most of your professional life..</h4>
                  
                    <div id="loginarea">
                       
                        <div id="login">

                            <Form method="POST" onSubmit={this.getRegister}>

                                <div className="form-group" id="iconlogin" >
                                    <i className="fa fa-envelope"></i>
                                    <Input type="email" className="form-control"
                                        value={this.state.email}
                                        onChange={(e) => { this.setState({ email: e.target.value }) }}
                                        name="email" id="Email1" required
                                        validations={[required, email]}
                                        aria-describedby="emailHelp" placeholder="Enter email" />
                                    <small id="emailHelp" className="form-text text-muted">Don't share this email to anyone.</small>
                                </div>
                                <div className="form-group" id="iconlogin2">
                                    <i className="fa fa-unlock-alt"></i>
                                    <Input type="password"
                                        value={this.state.password}
                                        onChange={(e) => { this.setState({ password: e.target.value }) }}
                                        className="form-control" name="password" id="password1" required
                                        validations={[required, isEqual]}
                                        placeholder="Password" />
                                </div>
                                <div className="form-group" id="iconlogin2" >
                                    <i className="fa fa-unlock-alt"></i>
                                    <Input type="password"
                                        value={this.state.password2} required
                                        onChange={(e) => { this.setState({ confirm: e.target.value }) }}
                                        className="form-control" name="confirm"
                                        validations={[required, isEqual]}
                                        id="repeatpassword" placeholder="Confirm Password" />
                                </div>


                                <div className="form-group" align="center">
                            <p>You agree to the MeetUp <b>User Agreement</b>, <b>Privacy Policy</b>, and <b>Cookie Policy</b>.</p>
                            {/* <button type="submit" class="btn join-btn-secondary join-btn" data-position-join="right"><span id="submit-join-form-text" class="fill-v2">Agree &amp; Join</span></button> */}
                                <button type="submit" className="btn btn-info">Agree & Join</button> &nbsp;
                        
                            </div>
                            </Form>

                        </div>

                     </div>
                      </div>
                    </div>
                </div>
                <NotificationSystem ref="notificationSystem" />
                
            </div>
            </div>

        );
    }
}

export default Register;