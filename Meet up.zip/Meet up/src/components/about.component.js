import React, { Component } from 'react';
import { Link } from "react-router-dom";

function About() {
    return (
         <div>
     <nav className=" navbar navbar-expand-lg navbar-light bg-info">
     <a className="navbar-brand" href="http://meetup.com"
       rel="noopener noreferrer" target="_blank">
         <img src='images/handshake.png' width="30" height="30"
           alt="logo is missing" />
       </a>
 
       {/* Routes */}
       <Link to ="/"
           className="navbar-brand">Meet-UP</Link>
           <button className="navbar-toggler" type="button"
           data-toggle ="collapse" data-target="#collapsibleNavbar">
             <span className="navbar-toggler-icon"></span>
           </button>
       <div className="collpase navbar-collapse">
         <ul className="navbar-nav mr-auto">
         <li className="nav-item">
             <Link to="/about" className="nav-link text-white fa fa-home">
               <b>Home</b>
             </Link>
             
             </li>
             </ul>
             <ul className="navbar-nav ml-auto">
             <li>
             <Link to="/register" className="nav-link text-white fa fa-user-circle-o">
               <b>Join-Now</b>
             </Link>
             <Link to="/login" className="nav-link text-white fa fa-user-circle-o">
               <b>Sign-in</b>
             </Link>
            
           </li>
         </ul>
       </div>
     </nav>  
        <div className="jumbotron" style={{backgroundImage: "url(images/login-background.jpg)"}}>
        {/* // <div className="container" style={{backgroundImage: "url(images/nature.jpg)"}}> */}
        <div className="container">

            {/* <Link to="/register" className="offset-lg-8 fa fa-handshake-o">
                 <strong>Join now</strong>
               </Link>
             
               <Link to="/login" className="offset-lg-8 fa fa-sign-in">
                 <strong>Sign in</strong>
               </Link> */}

            
                
                  <marquee>
                    <h1 className="text-danger" ><b>Welcome to your professional community - MeetUp</b></h1>
                    </marquee>
                    <hr />
                    <div className="row" style={{marginTop:20}}>
                    <div className="col-lg-6" >
                    <p className="lead text-">
                        <h2> About:</h2>
                    </p>
                    <h3 className="text-light">
                    <i className="fa fa-hand-o-right"/>&nbsp;
                        Meetup is a service used to organize online groups that host
                     in-person events for people<br /> with similar interests. Meetup
                      was founded in 2002 by CEO Scott Heiferman and<br /> four co-founders.
                       It was popularized by Howard Dean’s 2004 political campaign.<br />
                        The company was acquired by WeWork in 2017 and remains<br />
                        headquartered in New York City.
                    </h3>
                    <br/>
                    <br/>
                    <button type="button" style={{ fontSize: 20 }} className="btn btn-link fa fa-handshake-o">&nbsp;<a href="/register"><b>Join Now</b></a></button>
                    <button type="button" style={{ fontSize: 20 }} className="btn btn-link fa fa-sign-in">&nbsp;<a href="/login"><b>Sign In</b></a></button>

                </div>
                <div className="col-lg-6" style={{ paddingBottom: 320 }}>
                    <img src="images/image2.jpg"
                        alt="todo production"
                        width="400" height="400" className="img-thumbnail" />
                            
                </div>
                
            </div>
            <footer>
                {/* <img src="images/meeting.jpg"
                        alt="todo production"
                        width="200%" height="200%" className="img-thumbnail" /> */}

            </footer>
        </div>
</div>
</div>
    );
}
export default About;