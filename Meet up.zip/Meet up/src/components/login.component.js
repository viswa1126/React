import React from 'react';
import { NavLink } from 'react-router-dom';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { Icon } from 'semantic-ui-react';
import NotificationSystem from 'react-notification-system';


class Login extends React.Component {
    constructor(props) {
        super(props);
        this.state = {

            email: '',
            password: ''

        }
    }


    _notificationSystem = null

    _addNotification = (level, msg) => {
        //event.preventDefault();
        this._notificationSystem.addNotification({
            message: msg,
            level: level
        });
    }

    componentDidMount() {
        this._notificationSystem = this.refs.notificationSystem;

    }

    getLogIn = (e) => {
        e.preventDefault();
        axios.post('http://localhost:4000/users/login', this.state).then(res => {
            console.log(res.data);

            window.alert("You Have successfully Logged In");

            //  this._addNotification("success", "You have successfully LogIn.");
            if (res.status === 200) {
                console.log(res.data);
                localStorage.setItem("UserObject", JSON.stringify(res.data));
                window.location = '/create-profile';

            }
        })
            .catch(err => {
                console.log(err)
                console.log(err.response.data.msg);
                if (err.response.status === 401) {
                    this._addNotification("error", `${err.response.data.msg}`);
                }
                console.error(err.response);
                var errors = err.response.data.errors === undefined ? [] : err.response.data.errors;

                for (var i = 0; i < errors.length; i++) {
                    this._addNotification("error", `${i + 1} -> ${errors[i].param}: ${errors[i].msg}`)
                }


            });

    }

    render() {
        return (
            <div>
                <nav className=" navbar navbar-expand-lg navbar-light bg-info">
                    <a className="navbar-brand" href="http://meetup.com"
                        rel="noopener noreferrer" target="_blank">
                        <img src='images/handshake.png' width="30" height="30"
                            alt="logo is missing" />
                    </a>

                    {/* Routes */}
                    <Link to="/"
                        className="navbar-brand">Meet-UP</Link>
                    <button className="navbar-toggler" type="button"
                        data-toggle="collapse" data-target="#collapsibleNavbar">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collpase navbar-collapse">
                        <ul className="navbar-nav mr-auto">
                            <li className="nav-item">
                                <Link to="/about" className="nav-link text-white fa fa-home">
                                    <b>Home</b>
                                </Link>

                            </li>
                        </ul>
                        <ul className="navbar-nav ml-auto">
                            <li>
                                <Link to="/register" className="nav-link text-white fa fa-user-circle-o">
                                    <b>Join-Now</b>
                                </Link>
                                <Link to="/login" className="nav-link text-white fa fa-user-circle-o">
                                    <b>Sign-in</b>
                                </Link>

                            </li>
                        </ul>
                    </div>
                </nav>
                <div style={{ backgroundColor: "lightblue" }} >
                    <div id="loginarea" >
                        <div id="login" >
                            <div className="row">
                                <div className="offset-lg-4 col-lg-4">
                                    <h1 align="center">Welcome..!</h1>

                                    <h6 align="center">Don't miss your next opportunity.
                        Sign in to stay updated on your professional world.</h6>
                                    <br />

                                    <form method="POST" onSubmit={this.getLogIn}>
                                        <div className="form-group" id="iconlogin" >
                                            <i className="fa fa-envelope"></i>
                                            <input type="email"
                                                value={this.state.email}
                                                onChange={(e) => { this.setState({ email: e.target.value }) }}
                                                className="form-control" name="email" id="email" required aria-describedby="emailHelp" placeholder="Enter email" />
                                            <small id="emailHelp" className="form-text text-light ">We'll never share your email with anyone else.</small>
                                        </div>

                                        <div className="form-group" id="iconlogin2" >
                                            <i className="fa fa-unlock-alt"></i>
                                            <input type="password"
                                                value={this.state.password}
                                                onChange={(e) => { this.setState({ password: e.target.value }) }}
                                                className="form-control" name="password" required id="password" placeholder="Password" />

                                        </div>
                                        <button type="submit" className="btn btn-outline-dark btn-block"
                                        >Sign-In</button>
                                        <br />
                                        <center>
                                            <h3> OR..!</h3>
                                            <NavLink to='/register'><button className="btn btn-secondary"  >New User? Register Here</button></NavLink>
                                        </center>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <NotificationSystem ref="notificationSystem" />

                </div>
            </div>
        );
    }
}

export default Login;
