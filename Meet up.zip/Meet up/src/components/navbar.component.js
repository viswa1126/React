import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class Navbar extends Component {

    constructor() {
        super();
    }
    render() {
        return (
            <nav className=" navbar navbar-expand-lg navbar-light bg-info">
                <a className="navbar-brand" href="http://meetup.com"
                    rel="noopener noreferrer" target="_blank">
                    <img src='images/handshake.png' width="30" height="30"
                        alt="logo is missing" />
                </a>

                {/* Routes */}
                <Link to="/"
                    className="navbar-brand">Meet-UP</Link>
                <button className="navbar-toggler" type="button"
                    data-toggle="collapse" data-target="#collapsibleNavbar">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collpase navbar-collapse">
                    <ul className="navbar-nav mr-auto">
                        <li className="nav-item">
                            <Link to="/about" className="nav-link text-white fa fa-home">
                                <b>Home</b>
                            </Link>
                            <Link to="/create-profile" className="nav-link text-white fa fa-user">
                                <b>CreateProfile</b>
                            </Link>
                            <Link to="/post" className="nav-link text-white fa fa-commenting">
                                <b>Post</b>
                            </Link>
                        </li>
                    </ul>
                    <ul className="navbar-nav ml-auto">
                        <li>
                            <Link to="/myprofile" className="nav-link text-white fa fa-users">
                                <b>MyProfile</b>
                            </Link>
                            <Link to="/login" className="nav-link text-white fa fa-user-circle-o">
                                <b>Sign-in</b>
                            </Link>
                            <Link to="/login" className="nav-link text-white fa fa-sign-out">
                                <b>LogOut</b>
                            </Link>
                        </li>
                    </ul>
                </div>
            </nav>
        )
    }
}
export default Navbar;