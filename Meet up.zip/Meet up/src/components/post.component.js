import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { Badge } from 'reactstrap';
import Swal from 'sweetalert2';
import Navbar from './navbar.component';

class AddPost extends Component {
    constructor(props) {
        super(props);
        this.deletePost = this.deletePost.bind(this);

    }
    deletePost() {
        let result = window.confirm('Are you sure want to delete?')
        if (result) {
            axios.get('http://localhost:4000/post/delete/' + this.props.post._id)
                .then(console.log('Deleted Successfully'))
                .catch(err => console.log(err))
            window.location.reload();
        }
    }
    render() {
        return (

            <tr>
                <hr />

                <p >{this.props.post.addPost}</p><hr />

                <td>
                    <button onClick={this.deletePost} className="btn btn-link">Delete</button>
                </td>
            </tr>
        )
    }
}
export default class PostList extends Component {
    constructor(props) {
        super(props);
        this.state = { posts: [], id: '', };
        this.submitForm = this.submitForm.bind(this);
        this.onChangeAddPost = this.onChangeAddPost.bind(this);
        this.componentDidMount();
    } // end of constructor

    //life cycle hook
    componentDidMount() {
        axios.get("http://localhost:4000/post")
            .then(response => {
                this.setState({ posts: response.data });
            })
            .catch(function (error) {
                console.log(error);
            })
    }
    onChangeAddPost(e) {
        this.setState({
            addPost: e.target.value
        })
    }
    submitForm(event) {
        event.preventDefault();
        console.log(`Form submitted:`);
        const newPost = {
            addPost: this.state.addPost,
        }
        axios.post('http://localhost:4000/post/add', newPost)
            .then(res => console.log(res.data));
        alert("Your post added successfully..")
        window.location.reload();
        this.setState({
            addPost: ''
        })
    }

    postList() {
        return this.state.posts.map(function (currentPost, i) {
            return <AddPost post={currentPost} key={i} />
        })
    }
    render() {
        return (
            <div>
                <Navbar/>
            <div>
                <div style={{ marginTop: 10 }}>
                    <div className="container" style={{ backgroundImage: "url(images/log.jpg)" }}>

                        {/* <CreateProfile /> */}

                        <h3> No of Posts:&nbsp;<span className="badge badge-secondary">{this.state.posts.length}</span></h3>
                        <div className="offset-lg-3 col-lg-7">
                            <form>
                                <i className="fa fa-comments-o" />&nbsp;
                                <label><h3 className="text-success"><b>Add Post..!</b></h3></label>
                                <br />

                                <textarea type="text" rows="3" size="60" className="form-control" placeholder="What would you want to talk about.." name="addPost"
                                    onChange={this.onChangeAddPost} value={this.state.addPost}>
                                </textarea> &nbsp; &nbsp; &nbsp; &nbsp;
                            <br />
                                <center>
                                    <button type="button" onClick={this.submitForm}
                                        className="btn btn-secondary">post</button>
                                </center>

                            </form>
                            <br />
                            <br />
                            <br />



                            <div class="container">
                                <h3 > Your Posts Are..</h3>
                                <div class="card">
                                    <div class="card-header">  {this.postList()} </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        );
    }
}
