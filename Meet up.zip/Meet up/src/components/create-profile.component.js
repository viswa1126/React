import React from 'react';
import { TabContent, TabPane, Nav, NavItem, NavLink, Card, Button, CardTitle, CardText, Row, Col } from 'reactstrap';
import classnames from 'classnames';
import axios from 'axios';
import { Link } from 'react-router-dom';
import swal from 'sweetalert';
import MyProfile from './myprofile.component';
import Navbar from './navbar.component';

 

export default class Createprofile extends React.Component {
    constructor(props) {
        super(props);

        // binding text box onChange events
        this.onChangeFirstName = this.onChangeFirstName.bind(this);
        this.onChangeLastName = this.onChangeLastName.bind(this);
        this.onChangeJobTitle = this.onChangeJobTitle.bind(this);
        this.onChangeCompanyName = this.onChangeCompanyName.bind(this);
        this.onChangeStartDate = this.onChangeStartDate.bind(this);
        this.onChangeEndDate = this.onChangeEndDate.bind(this);
        this.onChangeQualification = this.onChangeQualification.bind(this);
        this.onChangeLocationName = this.onChangeLocationName.bind(this);
        this.onChangeMobileNumber = this.onChangeMobileNumber.bind(this);

        this.toggle = this.toggle.bind(this);

        // binding onSubmit event
        this.onSubmit = this.onSubmit.bind(this);
        this.clearForm = this.clearForm.bind(this);

        this.state = {
            first_name: '',
            last_name: '',
            job_title: '',
            company_name: '',
            start_date: '',
            end_date:'',
            qualification: '',
            location_name: '',
            mobile_number: '',

            activeTab: '1'
        }
    } // end of constructor

    onChangeFirstName(e){
        this.setState({
            first_name: e.target.value
        });
    }

    onChangeLastName(e){
        this.setState({
            last_name: e.target.value
        });
    }

    onChangeJobTitle(e) {
        this.setState({
            job_title: e.target.value
        });
    }
    onChangeCompanyName(e) {
        this.setState({
            company_name: e.target.value
        });
    }

    onChangeStartDate(e){
        this.setState({
            start_date: e.target.value
        });
    }
    onChangeEndDate(e){
        this.setState({
            end_date: e.target.value
        });
    }
    onChangeQualification(e) {
        this.setState({
            qualification: e.target.value
        });
    }
    onChangeLocationName(e) {
        this.setState({
            location_name: e.target.value
        });
    }
    onChangeMobileNumber(e) {
        this.setState({
            mobile_number: e.target.value
        });
    }

    onSubmit(e) {
        e.preventDefault();

        // console.log('Form submitted:');
        // console.log(`First Name: ${this.state.first_name}`);
        // console.log(`Last Name: ${this.state.last_name}`);
        // console.log(`Most recent job title: ${this.state.job_title}`);
        // console.log(`Company Name: ${this.state.company_name}`);
        // console.log(`Start Date: ${this.state.start_date}`);
        // console.log(`End Date: ${this.state.end_date}`);
        // console.log(`Qualification: ${this.state.qualification}`);
        // console.log(`Location Name: ${this.state.location_name}`);
        // console.log(`Mobile Number: ${this.state.mobile_number}`);

        const newProfile = {
            first_name: this.state.first_name,
            last_name: this.state.last_name,
            job_title: this.state.job_title,
            company_name: this.state.company_name,
            start_date: this.state.start_date,
            end_date: this.state.end_date,
            qualification: this.state.qualification,
            location_name: this.state.location_name,
            mobile_number: this.state.mobile_number,
        };

        // add
        axios.post('http://localhost:4000/profiles/add', newProfile)
            .then(res => console.log(res.data));
        alert('profile added successfully')
        this.clear(); 
        this.props.history.push('/myprofile');
    } // end of onSubmit() function

    clear() {
        this.setState({
            first_name: '',
            last_name: '',
            job_title: '',
            company_name: '',
            start_date: '',
            end_date: '',
            qualification: '',
            location_name: '',
            mobile_number: ''
        })
    }

    // clearing form fields
    clearForm(e) {
        e.preventDefault();
        this.clear();
    } // end of clearing form fields


    toggle(tab) {
        if (this.state.activeTab !== tab) {
            this.setState({
                activeTab: tab
            });
        }
    }


    render() {
        return (
          <div>
          
           <Navbar/>
          
            <div>
                <Nav tabs>
                    <NavItem>
                        <NavLink
                            className={classnames({ active: this.state.activeTab === '1' })}
                            onClick={() => { this.toggle('1'); }}>
                            Add Profile
            </NavLink>
                    </NavItem>
                    
                </Nav>
                <TabContent activeTab={this.state.activeTab}>
                    <TabPane tabId="1">
                    <div className="container">
                    <div className="jumbotron" style={{backgroundImage: "url(images/image.jpg)"}}> 
                    <div className="offset-lg-2 col-lg-8"> 
                        <div style={{ marginTop: 10 }}>
                            <h3 className="text-primary">Add Profile..!</h3>
                            <form onSubmit={this.onSubmit}>
                            <div className="form-group">
                                <i className="fa fa-user"/>&nbsp;
                                    <label>First Name</label>
                                    <input type="text" className="form-control"
                                        value={this.state.first_name}
                                        onChange={this.onChangeFirstName} required />
                                </div>
                                <div className="form-group">
                                <i className="fa fa-user"/>&nbsp;
                                    <label>Last Name</label>
                                    <input type="text" className="form-control"
                                        value={this.state.last_name}
                                        onChange={this.onChangeLastName} required />
                                </div>
                                <div className="form-group">
                                <i className="fa fa-info-circle"/>&nbsp;
                                    <label>Most recent Job Title</label>
                                    <input type="text" className="form-control"
                                        value={this.state.job_title}
                                        onChange={this.onChangeJobTitle} required />
                                </div>

                                <div className="form-group">
                                <i className="fa fa-building"/>&nbsp;
                                    <label>Most recent Company</label>
                                    <input type="text" className="form-control"
                                        value={this.state.company_name}
                                        onChange={this.onChangeCompanyName} required />
                                </div>
                                <div className="form-group">
                                <i className="fa fa-calendar"/>&nbsp;
                                    <label>Start Date</label>
                                    <input type="date" className="form-control"
                                        value={this.state.start_date}
                                        onChange={this.onChangeStartDate} required/>
                                </div>
                                <div className="form-group">
                                <i className="fa fa-calendar"/>&nbsp;
                                    <label>End Date</label>
                                    <input type="date" className="form-control"
                                        value={this.state.end_date}
                                        onChange={this.onChangeEndDate} required />
                                </div>
                                <div className="form-group">
                               
                                <i className="fa fa-file"/>&nbsp;
                                    <label>Qualification</label>
                                    <select id="slc" name="slc" class="form-control" value={this.state.qualification}
                                        onChange={this.onChangeQualification} required >
                                    <option value="select">Select</option>
                                    <option value="MCA">Masters In ComputerScience(M.C.A)</option>
                                    <option value="MBA">Masters In Business Administration(M.B.A)</option>
                                    <option value="MPA">Masters In Public Administration(M.P.A)</option>
                                    <option value="Others">Others</option>
                                </select>
                                </div>

                                <div className="form-group">
                                <i className="fa fa-map-marker"/>&nbsp;
                                    <label>Location</label>
                                    <select id="slc" name="slc" class="form-control" value={this.state.location_name}
                                        onChange={this.onChangeLocationName} required >
                                    <option value="select">Select</option>
                                    <option value="AndhraPradesh">AndhraPradesh</option>
                                    <option value="Tamilnadu">Tamilnadu</option>
                                    <option value="Kerala">Kerala</option>
                                    <option value="Karanataka">Karanataka</option>
                                    <option value="Mumbai">Mumbai</option>
                                    <option value="Pune">Pune</option>
                                    <option value="Hyderbad">Hyderbad</option>
                                </select>
                                        </div>

                                <div className="form-group">
                                <i className="fa fa-phone"/>&nbsp;
                                    <label>Phone Number</label>
                                    <input type="number" className="form-control"
                                        value={this.state.mobile_number}
                                        onChange={this.onChangeMobileNumber} required pattern="[6-9][0-9]{9}"/>
                                </div>

                                <div className="form-group">
                                    <input type="submit" value="Create Profile"
                                        className="btn btn-success" />&nbsp;
                        <button type="button" onClick={this.clearForm}
                                        className="btn btn-danger">Clear</button>
                                       
                                </div>
                            </form>
                            </div>
                        </div>
                        </div>
                        </div>
                     </TabPane>
                     
                 </TabContent>
             </div>
             </div>
        );
    }
}

