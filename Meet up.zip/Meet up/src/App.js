import React from 'react';
import logo from './logo.svg';
import './App.css';
import about from "./components/about.component";
import Login from "./components/login.component";
import MyProfile from "./components/myprofile.component";
import CreateProfile from "./components/create-profile.component";
import EditProfile from "./components/edit-profile.component";
import PostList from "./components/post.component";
import Register from "./components/register.component";

// step4- Router 
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
import Clock from './components/clock.component';

function App() {
  return (
   
    <Router>
   
        
        <br />
        {/* Configuring Route URLs for components */}
        <Route path="/" exact component={about} />
        <Route path="/about" exact component={about} />
        <Route path="/myprofile" exact component={MyProfile} />
        <Route path="/edit/:id" component={EditProfile} />
        <Route path="/login" component={Login} />
        <Route path="/post" component={PostList} />
        <Route path="/create-profile" component={CreateProfile} />
        <Route path="/register" component={Register} />
      <hr/>
     
      <h3>Follow us on..!</h3>
      <div className="row" style={{marginLeft: 10}}>
      
       <a href="http://facebook.com" target="_blank">
         <span className="text-primary">
           <i className="fa fa-facebook-square" style={{ fontSize: 25 }}></i>
         </span>
       </a>&nbsp;
         <a href="http://twitter.com" target="_blank">
         <span className="text-dark">
           <i className="fa fa-twitter" style={{ fontSize: 25 }}></i>
         </span>
       </a>&nbsp;
         <a href="http://google.com" target="_blank">
         <span className="text-danger">
           <i className="fa fa-google-plus-official" style={{ fontSize: 25 }}></i>
         </span>
       </a>&nbsp;
         <a href="http://whatsapp.com" target="_blank">
         <span className="text-success">
           <i className="fa fa-whatsapp" style={{ fontSize: 25 }}></i>
         </span>
       </a>&nbsp;
         <a href="http://youtube.com" target="_blank">
         <span className="text-danger">
           <i className="fa fa-youtube" style={{ fontSize: 25 }}></i>
         </span>
       </a>&nbsp;
         <a href="http://instagram.com" target="_blank">
         <span className="text-primary">
           <i className="fa fa-instagram" style={{ fontSize: 25 }}></i>
         </span>
       </a>
      <div className="offset-lg-8">
      <Clock />
        </div>

       </div>
       <footer className="text-center">
      This is subjected to &copy; Capgemini. All rights are reserved.
      </footer>
    </Router>
   
    
  );
}

export default App;
