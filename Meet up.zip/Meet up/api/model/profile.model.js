const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let Profile = new Schema({
    first_name: {
        type: String
    },
    last_name: {
        type: String
    },
    job_title: {
        type: String
    },
    company_name: {
        type: String
    },
    start_date: {
        type: String
    },
    end_date: {
        type: String
    },
    qualification: {
        type: String
    },
    location_name: {
        type: String
    },
    mobile_number: {
        type: String
    }
});

module.exports = mongoose.model('Profile', Profile);