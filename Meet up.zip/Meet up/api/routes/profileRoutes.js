const express = require('express');
const profileRoutes = express.Router();
let Profile = require('../model/profile.model');

profileRoutes.route('/').get(function (req,res) {
    Profile.find(function (err,profiles) {
        if (err) {
            console.log(err);
        } else {
            res.json(profiles);
        }
    });
});

profileRoutes.route('/').get(function (req,res) {
    let id = req.params.id;
    Profile.findById(id, function (err, profile) {
        res.json(profile);
    });
});

profileRoutes.route('/:id').get(function (req,res) {
    let id = req.params.id;
    Profile.findById(id, function (err, profile) {
        res.json(profile);
    });
});

 
profileRoutes.route('/add').post(function (req,res) {
    let profile = new Profile(req.body);
   
    profile.save()
        .then(profile => {
            res.status(200).json({ 'profile': 'Profile added successfully' });
        })
        .catch(err => {
            res.status(400).send('adding new profile failed');
        });
});

// Delete
profileRoutes.route('/delete/:id')
    .get(function (req,res) {
        Profile.deleteOne({ _id: req.params.id }, function (err, profile) {
            if (err) res.json(err);
            else res.json({
                message: 'Successfully removed',
                profile: profile
            });
        });
    });

// Update
profileRoutes.route('/update/:id').post(function (req,res) {
    Profile.findById(req.params.id, function (err, profile) {
        if (!profile)
            res.status(404).send("data is not found");
        else
            profile.first_name = req.body.first_name;
            profile.last_name = req.body.last_name;
            profile.job_title = req.body.job_title;
            profile.company_name = req.body.company_name;
            profile.start_date = req.body.start_date;
            profile.end_date = req.body.end_date;
            profile.qualification = req.body.qualification;
            profile.location_name = req.body.location_name; 
            profile.mobile_number = req.body.mobile_number;  

        profile.save().then(profile => {
            res.json('Profile updated!');
        })
        .catch(err => {
            res.status(400).send("update not possible");
        });
    });
});

module.exports = profileRoutes;