const express = require('express');
const postRoutes = express.Router();
let Post = require('../model/post.model');

postRoutes.route('/').get(function (req,res) {
    Post.find(function (err,posts) {
        if (err) {
            console.log(err);
        } else {
            res.json(posts);
        }
    });
});
//addPost
postRoutes.route('/add').post(function (req,res) {
    let post = new Post(req.body);
    post.save()
        .then(post => {
            res.status(200).json({ 'Post': 'Post added successfully' });
        })
        .catch(err => {
            res.status(400).send('adding new Post failed');
        });
});
// Delete post
postRoutes.route('/delete/:id')
    .get(function (req,res) {
        Post.deleteOne({ _id: req.params.id }, function (err, post) {
            if (err) res.json(err);
            else res.json({
                message: 'Successfully removed',
                post: post
            });
        });
    });

module.exports = postRoutes;